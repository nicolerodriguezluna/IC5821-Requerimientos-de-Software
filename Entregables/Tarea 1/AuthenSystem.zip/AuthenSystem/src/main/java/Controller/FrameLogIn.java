/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Controller;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author Nott
 */
public class FrameLogIn extends javax.swing.JFrame {

    /**
     * Creates new form FrameLogIn
     */
    public FrameLogIn() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        CreateAccount = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        FrameOne = new javax.swing.JTextField();
        NoAccessAccount = new javax.swing.JButton();
        ButtomNext = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bg.setBackground(new java.awt.Color(231, 222, 217));
        bg.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bg.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bg.setPreferredSize(new java.awt.Dimension(700, 600));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(168, 168, 168));

        jLabel2.setFont(new java.awt.Font("Microsoft JhengHei UI", 1, 18)); // NOI18N
        jLabel2.setText("Iniciar sesión");

        jPanel4.setBackground(new java.awt.Color(0, 103, 184));
        jPanel4.setPreferredSize(new java.awt.Dimension(305, 1));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 305, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1, Short.MAX_VALUE)
        );

        CreateAccount.setBackground(new java.awt.Color(255, 255, 255));
        CreateAccount.setForeground(new java.awt.Color(40, 127, 195));
        CreateAccount.setText("Cree una.");
        CreateAccount.setContentAreaFilled(false);
        CreateAccount.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        CreateAccount.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CreateAccountMouseClicked(evt);
            }
        });
        CreateAccount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreateAccountActionPerformed(evt);
            }
        });

        jLabel4.setText("¿No tiene ninguna cuenta?");

        FrameOne.setForeground(new java.awt.Color(102, 102, 102));
        FrameOne.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        FrameOne.setText("Correo electrónico, teléfono o Skype");
        FrameOne.setBorder(null);
        FrameOne.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        FrameOne.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        FrameOne.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FrameOneMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                FrameOneMousePressed(evt);
            }
        });
        FrameOne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FrameOneActionPerformed(evt);
            }
        });
        FrameOne.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                FrameOneKeyPressed(evt);
            }
        });

        NoAccessAccount.setBackground(new java.awt.Color(255, 255, 255));
        NoAccessAccount.setForeground(new java.awt.Color(40, 127, 195));
        NoAccessAccount.setText("¿No puede acceder a su cuenta?");
        NoAccessAccount.setContentAreaFilled(false);
        NoAccessAccount.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        NoAccessAccount.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        NoAccessAccount.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                NoAccessAccountMouseClicked(evt);
            }
        });
        NoAccessAccount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoAccessAccountActionPerformed(evt);
            }
        });

        ButtomNext.setBackground(new java.awt.Color(0, 103, 184));
        ButtomNext.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ButtomNext.setForeground(new java.awt.Color(255, 255, 255));
        ButtomNext.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ButtomNext.setLabel("Siguiente");
        ButtomNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtomNextActionPerformed(evt);
            }
        });
        ButtomNext.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ButtomNextKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(FrameOne, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(CreateAccount))
                                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel1)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(NoAccessAccount)
                        .addGap(18, 18, 18)
                        .addComponent(ButtomNext)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(FrameOne, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CreateAccount)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(NoAccessAccount, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ButtomNext)
                .addContainerGap())
        );

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addContainerGap(148, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(142, Short.MAX_VALUE))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(123, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, 636, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, 446, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CreateAccountMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CreateAccountMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_CreateAccountMouseClicked

    private void CreateAccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreateAccountActionPerformed
        // TODO add your handling code here:
        CreateNewAccount FrameCA = new CreateNewAccount();
        FrameCA.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_CreateAccountActionPerformed

    private void FrameOneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FrameOneMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_FrameOneMouseClicked

    private void FrameOneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FrameOneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FrameOneActionPerformed

    private void NoAccessAccountMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NoAccessAccountMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_NoAccessAccountMouseClicked

    private void NoAccessAccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NoAccessAccountActionPerformed
        // TODO add your handling code here:
        FrameAccountRecuperation FrameRA = new FrameAccountRecuperation();
        FrameRA.setVisible(true);
        this.setVisible(false); 
    }//GEN-LAST:event_NoAccessAccountActionPerformed

    private void ButtomNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtomNextActionPerformed
        // TODO add your handling code here:
        String email = FrameOne.getText();
        if(emailValidation(email)){
            PasswordLogIn FrameP = new PasswordLogIn();
            FrameP.setVisible(true);
            this.setVisible(false);
        }else{
             JOptionPane.showMessageDialog(bg, "Correo no tiene el formato correcto");
        }
    }//GEN-LAST:event_ButtomNextActionPerformed

    private void FrameOneMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FrameOneMousePressed
        // TODO add your handling code here:
        if (FrameOne.getText().equals("Correo electrónico, teléfono o Skype")){
            FrameOne.setText(""); 
            FrameOne.setForeground(Color.black);
        } 
    }//GEN-LAST:event_FrameOneMousePressed
    public boolean emailValidation(String email) {
       String reg = "^(.+)@(\\S+)$";
       Pattern pattern = Pattern.compile(reg);
       Matcher matcher = pattern.matcher(email);
       return matcher.matches();
    }
    private void FrameOneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_FrameOneKeyPressed
        // TODO add your handling code here:
      int key = evt.getKeyCode();  // Keyboard code for the pressed key.
      if (key == KeyEvent.VK_ENTER) {
        String email = FrameOne.getText();
        if(emailValidation(email)){
            PasswordLogIn FrameP = new PasswordLogIn();
            FrameP.setVisible(true);
            this.setVisible(false);
        }else{
             JOptionPane.showMessageDialog(bg, "Correo no tiene el formato correcto");
        }
      }
    }//GEN-LAST:event_FrameOneKeyPressed

    private void ButtomNextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ButtomNextKeyPressed
        // TODO add your handling code here:
        String email = FrameOne.getText();
        if(emailValidation(email)){
            PasswordLogIn FrameP = new PasswordLogIn();
            FrameP.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_ButtomNextKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrameLogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrameLogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrameLogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrameLogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameLogIn().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtomNext;
    private javax.swing.JButton CreateAccount;
    private javax.swing.JTextField FrameOne;
    private javax.swing.JButton NoAccessAccount;
    private javax.swing.JPanel bg;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    // End of variables declaration//GEN-END:variables
}
